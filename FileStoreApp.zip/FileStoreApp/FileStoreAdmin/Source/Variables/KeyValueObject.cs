﻿
namespace FileStoreAdmin.Source.Variables
{
    class KeyValueObject
    {

        public string Text { get; set; }

        public string Value { get; set; }

    }
}