﻿namespace FileStoreApp.Source.Variables
{
    internal class Constants
    {
        public static readonly string FileList_ColumnList = "Id[i]-Dosya Adı-Oluşturan Kullanıcı-KulId[i]-Oluşturulma Tarihi";
    }
}